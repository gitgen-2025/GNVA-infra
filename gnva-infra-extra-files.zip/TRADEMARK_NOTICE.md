# GNVA™ Trademark Notice

GNVA™ is a trademark owned by Geneva Macabuhay.

This trademark may not be used in connection with any product or service that is not GNVA’s, without prior written permission.

Usage in forks, derivatives, or alternative remittance services must clearly state independence from the original GNVA™ infrastructure project.
